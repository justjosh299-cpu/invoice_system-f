OMG COMPUTER DIAGNOSTIC SYSTEM V11
==================================

NEW IN V11 — INVOICING
----------------------
- Create invoices from any ticket or standalone
- Line items with description, qty, unit price
- Discount, VAT, auto-computed subtotal / tax / total / balance
- Record partial or full payments (Cash, Mobile Money, Bank, Cheque, Card)
- Statuses: DRAFT, SENT, PARTIAL, PAID, OVERDUE, CANCELLED
  (OVERDUE is computed automatically when due date passes)
- Print and PDF export with logo, coat of arms or letterhead banner
- QR code on each invoice links to client portal
- Email invoice PDF to client (uses SMTP settings)
- Client detail page now shows both tickets and invoices
- Dashboard cards: Unpaid, Overdue, Paid-this-month
- Portal now supports invoice lookup by phone + invoice number

SETTINGS
--------
Settings → Invoice Settings:
  - Invoice prefix (default INV)
  - Currency (default UGX)
  - Default VAT rate (default 18%)
  - Default due days (default 14)
  - Default terms text

HOW TO USE
----------
1. From a ticket: open the report → "Create Invoice" (if built into view_report)
   OR click Invoices in the nav → + New Invoice
2. Add line items — description, qty, unit price
3. Save → view invoice
4. Record Payment when cash / MoMo / bank arrives
5. Email PDF or print — invoice shows balance due and payment history

INSTALL / UPGRADE
-----------------
1. Drop install.php in the folder
2. Visit it once
3. Delete install.php
4. Login: admin / admin123

The installer is safe to re-run — migrations use try/catch.

DEFAULT LOGIN
-------------
admin / admin123