OMG DIAGNOSTIC SYSTEM — v14.2 (Part 2 of 2)
==========================================

NEW IN v14.2
------------
1. BULK STATUS CHANGE       reports.php
   - Checkbox column on reports list
   - "Bulk action" bar appears when items selected
   - Actions: Close Selected, Export Selected (Excel)

2. TECHNICIAN DASHBOARD      my_tickets.php
   - Shows only tickets assigned to the current user
   - Filter: hide/show closed

3. WHATSAPP SHARE            on view_report.php + invoice_view.php
   - One-click opens wa.me link with a pre-filled message

4. BRAND COLOUR              settings.php
   - Input for brand hex colour
   - Used in nav bar background

5. GLOBAL SEARCH             search.php
   - Search box in nav (top-right)
   - Finds tickets, invoices, and clients in one page

6. DARK MODE EVERYWHERE      profile.php → Theme
   - Real dark theme across the app (not just Profile)

7. LOGIN AUDIT LOG           login_audit.php (admin only)
   - Every login attempt (success / failure) with IP, UA, time
   - Auto-logged from login.php

8. BUTTON WIRING
   - view_report.php: Cost Worksheet, Deposits, WhatsApp, Statement
   - client_view.php: Statement, Excel export

INSTALL
-------
1. Save as install.php, run once
2. Delete install.php
3. Add to config.php (near the top, after other require_once lines):
      require_once __DIR__ . '/config_v142.php';
4. Add login logging to login.php — see README on disk
5. Hard-refresh browser (Ctrl+F5)

NAV ADDITIONS
-------------
<a href="search.php" class="navsearch">
  <input type="text" placeholder="Search..." style="...">
</a>
<a href="my_tickets.php">My Tickets</a>       (non-admin)
<a href="login_audit.php">Login Audit</a>     (admin)
