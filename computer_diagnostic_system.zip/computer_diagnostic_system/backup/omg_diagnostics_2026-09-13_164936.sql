-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: omg_diagnostics
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_log`
--

DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `ticket_no` varchar(40) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_ticket` (`ticket_no`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_log`
--

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES (1,1,'Created diagnostic report','OMG-2026-00001','2026-09-13 12:59:10'),(2,1,'Created diagnostic report (printer)','OMG-2026-00002','2026-09-13 13:14:55'),(3,1,'Created diagnostic report (printer)','OMG-2026-00003','2026-09-13 13:26:05'),(4,1,'Deleted diagnostic report','OMG-2026-00003','2026-09-13 13:56:05'),(5,1,'Created diagnostic report (computer)','OMG-2026-00003','2026-09-13 13:57:53'),(6,1,'Updated diagnostic report','OMG-2026-00003','2026-09-13 13:58:11'),(7,1,'Updated diagnostic report','OMG-2026-00001','2026-09-13 13:58:51'),(8,1,'Signed out',NULL,'2026-09-13 14:08:41'),(9,1,'Signed in',NULL,'2026-09-13 14:08:49'),(10,1,'Created user: emmanuelokure@omg.com (technician)',NULL,'2026-09-13 14:28:01'),(11,1,'Reset password for user #1',NULL,'2026-09-13 14:28:33'),(12,1,'Reset password for user #1',NULL,'2026-09-13 14:28:40'),(13,1,'Signed out',NULL,'2026-09-13 14:28:43'),(14,1,'Signed in',NULL,'2026-09-13 14:28:52'),(15,1,'Signed out',NULL,'2026-09-13 14:29:09'),(16,2,'Signed in',NULL,'2026-09-13 14:29:27'),(17,2,'Signed out',NULL,'2026-09-13 14:30:12'),(18,1,'Signed in',NULL,'2026-09-13 14:30:28'),(19,1,'Updated backup key',NULL,'2026-09-13 14:48:30');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_name` varchar(180) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(60) DEFAULT NULL,
  `alternate_phone` varchar(60) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (1,'omg technologies','SOROTI','0778508802','0778508802','2026-09-13 12:59:10'),(2,'omg technologies','SOROTI','0778508802','0778508802','2026-09-13 13:13:18'),(3,'omg technologies','SOROTI','0778508802','0778508802','2026-09-13 13:14:55'),(4,'omg technologies','SOROTI','0778508802','0778508802','2026-09-13 13:24:11'),(5,'omg technologies','SOROTI','0778508802','0778508802','2026-09-13 13:24:53'),(7,'soroti ss','SOROTI','0778508802','0778508802','2026-09-13 13:57:53');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diagnostic_items`
--

DROP TABLE IF EXISTS `diagnostic_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `diagnostic_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_id` int(11) NOT NULL,
  `diagnostic_area` varchar(120) NOT NULL,
  `status` varchar(40) DEFAULT 'Not Checked',
  `findings` text DEFAULT NULL,
  `recommendation` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `report_id` (`report_id`),
  CONSTRAINT `diagnostic_items_ibfk_1` FOREIGN KEY (`report_id`) REFERENCES `reports` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diagnostic_items`
--

LOCK TABLES `diagnostic_items` WRITE;
/*!40000 ALTER TABLE `diagnostic_items` DISABLE KEYS */;
INSERT INTO `diagnostic_items` VALUES (10,2,'Power / Cabling','Functional','',''),(11,2,'Print Head / Cartridge','Functional','shorted',''),(12,2,'Toner / Ink System','Functional','',''),(13,2,'Paper Feed / Rollers','Functional','',''),(14,2,'Fuser Unit','Functional','',''),(15,2,'Scanner / ADF Glass','Functional','',''),(16,2,'Photocopy Module','Functional','',''),(17,2,'Control Panel / Display','Functional','',''),(18,2,'Connectivity (USB / Network / Wi-Fi)','Functional','',''),(19,2,'Drivers / Software','Fault','dff',''),(39,4,'Power / Battery','Fault','dead',''),(40,4,'RAM / Memory','Functional','',''),(41,4,'Storage Drive','Functional','',''),(42,4,'Operating System','Functional','',''),(43,4,'Device Drivers','Functional','',''),(44,4,'CPU / Processor','Functional','',''),(45,4,'Display / Graphics','Functional','',''),(46,4,'Network / Wi-Fi','Functional','',''),(47,4,'Ports / USB','Functional','',''),(48,1,'Power / Battery','Functional','',''),(49,1,'RAM / Memory','Fault','dff',''),(50,1,'Storage Drive','Functional','',''),(51,1,'Operating System','Functional','',''),(52,1,'Device Drivers','Functional','',''),(53,1,'CPU / Processor','Functional','',''),(54,1,'Display / Graphics','Functional','',''),(55,1,'Network / Wi-Fi','Fault','dd',''),(56,1,'Ports / USB','Functional','','');
/*!40000 ALTER TABLE `diagnostic_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_no` varchar(40) NOT NULL,
  `device_type` varchar(20) DEFAULT 'computer',
  `client_id` int(11) DEFAULT NULL,
  `technician_id` int(11) DEFAULT NULL,
  `reported_date` date NOT NULL,
  `computer_make_model` varchar(180) DEFAULT NULL,
  `serial_number` varchar(120) DEFAULT NULL,
  `work_ticket_number` varchar(80) DEFAULT NULL,
  `problem_categories` text DEFAULT NULL,
  `problem_description` text DEFAULT NULL,
  `recommended_fix` text DEFAULT NULL,
  `estimated_cost` decimal(12,2) DEFAULT NULL,
  `estimated_completion` varchar(120) DEFAULT NULL,
  `items_received` text DEFAULT NULL,
  `client_initials` varchar(30) DEFAULT NULL,
  `authorization` tinyint(4) DEFAULT 0,
  `technician_name` varchar(120) DEFAULT NULL,
  `repaired_date` date DEFAULT NULL,
  `verified_by` varchar(120) DEFAULT NULL,
  `final_result` varchar(50) DEFAULT NULL,
  `action_taken` text DEFAULT NULL,
  `parts_replaced` text DEFAULT NULL,
  `software_installed` text DEFAULT NULL,
  `technician_remarks` text DEFAULT NULL,
  `diagnostic_start` date DEFAULT NULL,
  `diagnostic_end` date DEFAULT NULL,
  `repair_start` date DEFAULT NULL,
  `repair_end` date DEFAULT NULL,
  `ticket_status` varchar(40) DEFAULT 'OPEN',
  `print_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ticket_no` (`ticket_no`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
INSERT INTO `reports` VALUES (1,'OMG-2026-00001','computer',1,NULL,'2026-09-13','hp elitebook','22293433934444','123333','CD/DVD-ROM, Won’t Boot – Software','','sdsd',300000.00,'','Mouse/Keyboard, Recovery Media, Driver Software','dfdfdff',1,'Mr. OKELLO Joshua','2026-09-17','dfdfdf','Repaired','dfff','werwrw','wweqweqw','ww','2026-09-13',NULL,'2026-09-17','2026-09-26','OPEN','2026-09-13','2026-09-13 12:59:10','2026-09-13 12:59:10'),(2,'OMG-2026-00002','printer',3,NULL,'2026-09-13','hp elitebook','22293433934444','123333','Printer, Toner / Ink Problem, Photocopy Fault, Error Code Displayed','','',NULL,'','Printer, Scanner, Paper Tray','dfdfdff',1,'Mr. OKELLO Joshua',NULL,'okello joshua','Repaired','wdsd','dsd','dsda','sdasd','2026-09-13',NULL,'2026-09-13','2026-09-13','OPEN','2026-09-13','2026-09-13 13:14:55','2026-09-13 13:14:55'),(4,'OMG-2026-00003','computer',7,NULL,'2026-09-13','dell inspiron','2m383822034332','','USB / Removable Drive, Network / Wi-Fi','','',NULL,'','Laptop Case','sss',1,'Mr. OKELLO Joshua',NULL,'joshua okello','Repaired','dd','ee','ee','d','2026-09-13','2026-09-13','2026-09-13','2026-09-20','AWAITING PARTS','2026-09-13','2026-09-13 13:57:53','2026-09-13 13:57:53');
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `setting_key` varchar(60) NOT NULL,
  `setting_value` text DEFAULT NULL,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES ('backup_key','56b2bd99f8a0a1ed769486d8'),('coat_of_arms','assets/uploads/coat_of_arms.jpg'),('company_logo','assets/uploads/company_logo.jpg');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(80) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(120) NOT NULL,
  `role` varchar(30) DEFAULT 'technician',
  `active` tinyint(4) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','$2y$10$gSlV3j8KvAkL6h/93LUbW.rjzc16bIAV7U/.D7jagz2FgJJMWtKFO','Mr. OKELLO Joshua','admin',1,'2026-09-13 12:22:15'),(2,'emmanuelokure@omg.com','$2y$10$uoZltW441P7xTmIUMySFrufCiU4Ut1tk7mQ0Xyukdba50j1RSw0ra','okure emmanuel','technician',1,'2026-09-13 14:28:01');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'omg_diagnostics'
--

--
-- Dumping routines for database 'omg_diagnostics'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-13 17:49:36
