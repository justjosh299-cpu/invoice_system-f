-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: omg_diagnostics
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_log`
--

DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `ticket_no` varchar(40) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_ticket` (`ticket_no`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_log`
--

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES (1,1,'Created diagnostic report','OMG-2026-00001','2026-09-13 12:59:10'),(2,1,'Created diagnostic report (printer)','OMG-2026-00002','2026-09-13 13:14:55'),(3,1,'Created diagnostic report (printer)','OMG-2026-00003','2026-09-13 13:26:05'),(4,1,'Deleted diagnostic report','OMG-2026-00003','2026-09-13 13:56:05'),(5,1,'Created diagnostic report (computer)','OMG-2026-00003','2026-09-13 13:57:53'),(6,1,'Updated diagnostic report','OMG-2026-00003','2026-09-13 13:58:11'),(7,1,'Updated diagnostic report','OMG-2026-00001','2026-09-13 13:58:51'),(8,1,'Signed out',NULL,'2026-09-13 14:08:41'),(9,1,'Signed in',NULL,'2026-09-13 14:08:49'),(10,1,'Created user: emmanuelokure@omg.com (technician)',NULL,'2026-09-13 14:28:01'),(11,1,'Reset password for user #1',NULL,'2026-09-13 14:28:33'),(12,1,'Reset password for user #1',NULL,'2026-09-13 14:28:40'),(13,1,'Signed out',NULL,'2026-09-13 14:28:43'),(14,1,'Signed in',NULL,'2026-09-13 14:28:52'),(15,1,'Signed out',NULL,'2026-09-13 14:29:09'),(16,2,'Signed in',NULL,'2026-09-13 14:29:27'),(17,2,'Signed out',NULL,'2026-09-13 14:30:12'),(18,1,'Signed in',NULL,'2026-09-13 14:30:28'),(19,1,'Updated backup key',NULL,'2026-09-13 14:48:30'),(20,1,'Database backup: omg_diagnostics_2026-09-13_164936.sql',NULL,'2026-09-13 14:49:36'),(21,1,'Uploaded letterhead banner',NULL,'2026-09-13 15:00:28'),(22,1,'Removed coat of arms',NULL,'2026-09-13 15:04:36'),(23,1,'Removed letterhead banner',NULL,'2026-09-13 15:04:51'),(24,1,'Uploaded coat of arms',NULL,'2026-09-13 15:05:08'),(25,1,'Signed out',NULL,'2026-09-13 15:05:46'),(26,2,'Signed in',NULL,'2026-09-13 15:21:56'),(27,2,'Signed out',NULL,'2026-09-13 15:26:12'),(28,1,'Signed in',NULL,'2026-09-13 15:27:12'),(29,1,'Reset password for user #1',NULL,'2026-09-13 15:27:38'),(30,1,'Deleted diagnostic report','OMG-2026-00002','2026-09-13 15:31:27'),(31,1,'Signed out',NULL,'2026-09-15 07:25:51'),(32,1,'Signed in',NULL,'2026-09-15 07:25:59'),(33,1,'Reset password for user #1',NULL,'2026-09-15 07:26:19'),(34,1,'Signed out',NULL,'2026-09-15 07:26:24'),(35,1,'Signed in',NULL,'2026-09-15 07:26:33'),(36,1,'Created diagnostic report (computer)','OMG-2026-00004','2026-09-16 05:58:35'),(37,1,'Created diagnostic report (printer)','OMG-2026-00005','2026-09-16 07:22:02'),(38,1,'Updated diagnostic report','OMG-2026-00005','2026-09-16 07:24:27'),(39,1,'Updated email (SMTP) settings',NULL,'2026-09-16 07:27:07'),(40,1,'Updated diagnostic report','OMG-2026-00005','2026-09-16 07:40:07'),(41,1,'Updated user #2',NULL,'2026-09-16 07:49:06'),(42,1,'Updated user #2',NULL,'2026-09-16 07:49:11'),(43,1,'Signed out',NULL,'2026-09-16 07:49:22'),(44,2,'Signed in',NULL,'2026-09-16 07:50:03'),(45,2,'Deleted diagnostic report','OMG-2026-00001','2026-09-16 07:51:24'),(46,2,'Updated diagnostic report','OMG-2026-00003','2026-09-16 09:08:20'),(47,2,'Created diagnostic report (computer)','OMG-2026-00006','2026-09-16 09:47:26'),(48,2,'Updated diagnostic report','OMG-2026-00006','2026-09-16 09:49:39'),(49,2,'Updated diagnostic report','OMG-2026-00006','2026-09-16 09:59:58'),(50,2,'Updated diagnostic report','OMG-2026-00006','2026-09-16 10:04:02'),(51,2,'Updated diagnostic report','OMG-2026-00006','2026-09-16 10:05:12'),(52,2,'Updated diagnostic report','OMG-2026-00006','2026-09-16 10:05:56'),(53,2,'Status changed: OPEN → DIAGNOSIS','OMG-2026-00006','2026-09-16 10:05:56'),(54,2,'Updated diagnostic report','OMG-2026-00005','2026-09-16 14:12:26'),(55,2,'Updated diagnostic report','OMG-2026-00003','2026-09-17 17:12:29'),(56,2,'Updated diagnostic report','OMG-2026-00006','2026-09-17 17:15:08'),(57,2,'Signed out',NULL,'2026-09-17 17:15:29'),(58,1,'Signed in',NULL,'2026-09-17 17:15:57'),(59,1,'Created diagnostic report (computer)','OMG-2026-00007','2026-09-17 17:17:00'),(60,1,'Updated diagnostic report','OMG-2026-00007','2026-09-17 18:20:45'),(61,1,'Status changed: OPEN → CLOSED','OMG-2026-00007','2026-09-17 18:20:45'),(62,1,'Uploaded company logo',NULL,'2026-09-17 19:07:30'),(63,1,'Uploaded coat of arms',NULL,'2026-09-17 19:07:30'),(64,1,'Uploaded company logo',NULL,'2026-09-17 19:07:30'),(65,1,'Uploaded coat of arms',NULL,'2026-09-17 19:07:30'),(66,1,'Updated diagnostic report','OMG-2026-00003','2026-09-17 19:11:14'),(67,1,'Signed out',NULL,'2026-09-17 21:50:49'),(68,1,'Signed in',NULL,'2026-09-21 03:35:53');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_name` varchar(180) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(60) DEFAULT NULL,
  `alternate_phone` varchar(60) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (2,'omg technologies','SOROTI','0778508802','0778508802','2026-09-13 13:13:18'),(4,'omg technologies','SOROTI','0778508802','0778508802','2026-09-13 13:24:11'),(5,'omg technologies','SOROTI','0778508802','0778508802','2026-09-13 13:24:53'),(7,'moha','SOROTI','','','2026-09-13 13:57:53'),(8,'Mr. Echabu Francis','SHOA INSTITUTE','','','2026-09-16 05:58:35'),(9,'AS ONE MEDICAL CENTER','KABERAMAIDO','','','2026-09-16 07:22:02'),(10,'STELLA','SOROTI','','','2026-09-16 09:47:26'),(11,'Erongu jorem Paul','Moru apesur','0761875531','','2026-09-17 17:17:00');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diagnostic_items`
--

DROP TABLE IF EXISTS `diagnostic_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `diagnostic_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_id` int(11) NOT NULL,
  `diagnostic_area` varchar(120) NOT NULL,
  `status` varchar(40) DEFAULT 'Not Checked',
  `findings` text DEFAULT NULL,
  `recommendation` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `report_id` (`report_id`),
  CONSTRAINT `diagnostic_items_ibfk_1` FOREIGN KEY (`report_id`) REFERENCES `reports` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=214 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diagnostic_items`
--

LOCK TABLES `diagnostic_items` WRITE;
/*!40000 ALTER TABLE `diagnostic_items` DISABLE KEYS */;
INSERT INTO `diagnostic_items` VALUES (57,5,'Power / Battery','Functional','',''),(58,5,'RAM / Memory','Functional','',''),(59,5,'Storage Drive','Functional','',''),(60,5,'Operating System','Functional','',''),(61,5,'Device Drivers','Functional','',''),(62,5,'CPU / Processor','Functional','',''),(63,5,'Display / Graphics','Functional','',''),(64,5,'Network / Wi-Fi','Functional','',''),(65,5,'Ports / USB','Functional','',''),(159,6,'Power / Cabling','Functional','',''),(160,6,'Print Head / Cartridge','Fault','Toner Catridge Reached end of life',''),(161,6,'Toner / Ink System','Fault','very low toner',''),(162,6,'Paper Feed / Rollers','Fault','run beyond limit',''),(163,6,'Fuser Unit','Fault','run beyond limit',''),(164,6,'Scanner / ADF Glass','Functional','',''),(165,6,'Photocopy Module','Functional','',''),(166,6,'Control Panel / Display','Functional','',''),(167,6,'Connectivity (USB / Network / Wi-Fi)','Functional','',''),(168,6,'Drivers / Software','Functional','',''),(178,7,'Power / Battery','Functional','',''),(179,7,'RAM / Memory','Functional','',''),(180,7,'Storage Drive','Functional','',''),(181,7,'Operating System','Functional','',''),(182,7,'Device Drivers','Functional','',''),(183,7,'CPU / Processor','Functional','',''),(184,7,'Display / Graphics','Functional','',''),(185,7,'Network / Wi-Fi','Functional','',''),(186,7,'Ports / USB','Functional','',''),(196,8,'Power / Battery','Not Checked','',''),(197,8,'RAM / Memory','Not Checked','',''),(198,8,'Storage Drive','Not Checked','',''),(199,8,'Operating System','Not Checked','',''),(200,8,'Device Drivers','Not Checked','',''),(201,8,'CPU / Processor','Needs Attention','',''),(202,8,'Display / Graphics','Needs Attention','',''),(203,8,'Network / Wi-Fi','Not Checked','',''),(204,8,'Ports / USB','Not Checked','',''),(205,4,'Power / Battery','Functional','',''),(206,4,'RAM / Memory','Functional','',''),(207,4,'Storage Drive','Functional','',''),(208,4,'Operating System','Functional','',''),(209,4,'Device Drivers','Not Checked','',''),(210,4,'CPU / Processor','Functional','',''),(211,4,'Display / Graphics','Needs Attention','',''),(212,4,'Network / Wi-Fi','Functional','',''),(213,4,'Ports / USB','Functional','','');
/*!40000 ALTER TABLE `diagnostic_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_no` varchar(40) NOT NULL,
  `device_type` varchar(20) DEFAULT 'computer',
  `client_id` int(11) DEFAULT NULL,
  `technician_id` int(11) DEFAULT NULL,
  `reported_date` date NOT NULL,
  `computer_make_model` varchar(180) DEFAULT NULL,
  `serial_number` varchar(120) DEFAULT NULL,
  `work_ticket_number` varchar(80) DEFAULT NULL,
  `problem_categories` text DEFAULT NULL,
  `problem_description` text DEFAULT NULL,
  `recommended_fix` text DEFAULT NULL,
  `estimated_cost` decimal(12,2) DEFAULT NULL,
  `estimated_completion` varchar(120) DEFAULT NULL,
  `items_received` text DEFAULT NULL,
  `client_initials` varchar(30) DEFAULT NULL,
  `authorization` tinyint(4) DEFAULT 0,
  `technician_name` varchar(120) DEFAULT NULL,
  `repaired_date` date DEFAULT NULL,
  `verified_by` varchar(120) DEFAULT NULL,
  `final_result` varchar(50) DEFAULT NULL,
  `action_taken` text DEFAULT NULL,
  `parts_replaced` text DEFAULT NULL,
  `software_installed` text DEFAULT NULL,
  `technician_remarks` text DEFAULT NULL,
  `diagnostic_start` date DEFAULT NULL,
  `diagnostic_end` date DEFAULT NULL,
  `repair_start` date DEFAULT NULL,
  `repair_end` date DEFAULT NULL,
  `ticket_status` varchar(40) DEFAULT 'OPEN',
  `print_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ticket_no` (`ticket_no`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reports`
--

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
INSERT INTO `reports` VALUES (4,'OMG-2026-00003','computer',7,NULL,'2026-09-13','Dell inspiron','2m383822034332','','Won’t Boot – Hardware','Fans spin but  no display','Onboard graphics card replacement',250000.00,'','Laptop Case','moha',1,'Mr. OKELLO Joshua',NULL,'joshua okello','Awaiting Parts','NULL','NULL','NULL','','2026-09-13','2026-09-13','2026-09-13','2026-09-20','AWAITING PARTS','2026-09-13','2026-09-13 13:57:53','2026-09-17 19:11:14'),(5,'OMG-2026-00004','computer',8,NULL,'2026-09-16','hp elitebook','C3428890732','2000/8/034','Won’t Boot – Hardware','','replace power switching board',30000.00,'14/09/2026','Laptop Case','E.F',1,'Mr. OKELLO Joshua','2026-08-16','Mr. JOSHUA OKELLO','Repaired','Parts replacement','POWER ON/OFF SWITCH SYSTEM','NULL','computer 💻 runs efficiently','2026-09-08','2026-09-13','2026-09-14','2026-09-14','CLOSED','2026-09-16','2026-09-16 05:58:35','2026-09-16 05:58:35'),(6,'OMG-2026-00005','printer',9,NULL,'2026-09-16','HP Leaser MFP 135w','4ZB83A','','Printer','Blur images, Lines and Faint printouts\r\n','',NULL,'','Printer','',1,'okure emmanuel','2026-09-16','Mr. okello joshua','Repaired','','1.Toner catridge\r\n2.Fuser Unit\r\n3.Pickup roller','','','2026-09-16','2026-09-16','2026-09-16','2026-09-16','OPEN','2026-09-16','2026-09-16 07:22:02','2026-09-16 14:12:26'),(7,'OMG-2026-00006','computer',10,NULL,'2026-09-16','DELL Latitude 3340','35641738046','','Won’t Boot – Hardware, No Power','','',NULL,'','Laptop Case','',1,'okure emmanuel',NULL,'','Repaired','','','','',NULL,NULL,NULL,NULL,'DIAGNOSIS','2026-09-16','2026-09-16 09:47:26','2026-09-17 17:15:08'),(8,'OMG-2026-00007','computer',11,NULL,'2026-09-17','HP Probook6460b','6043B0090102','','Won’t Boot – Hardware','broken casing','Housing/Casing Replacement ',150000.00,'','Laptop Case','',1,'Mr. OKELLO Joshua',NULL,'Mr. Okello Joshua','Repaired','NULL','NULL','NULL','replace the laptop casing with an apropriate and compatible form-factor',NULL,'2026-09-17',NULL,NULL,'CLOSED','2026-09-17','2026-09-17 17:17:00','2026-09-17 18:20:45');
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `setting_key` varchar(60) NOT NULL,
  `setting_value` text DEFAULT NULL,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES ('backup_key','56b2bd99f8a0a1ed769486d8'),('coat_of_arms','assets/uploads/coat_of_arms.png'),('company_logo','assets/uploads/company_logo.png'),('header_mode','classic'),('smtp_from','justjosh299@gmail.com'),('smtp_from_name','OMG Technologies Uganda'),('smtp_host','justjosh299@gmail.com'),('smtp_pass',''),('smtp_port','587'),('smtp_secure','tls'),('smtp_user','justjosh299@gmail.com');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(80) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(120) NOT NULL,
  `role` varchar(30) DEFAULT 'technician',
  `active` tinyint(4) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','$2y$10$GiPLp8m8frsLGlnJyzojjOwCrlBv0WKsRy3qOj1F6QO0/X5P1oU66','Mr. OKELLO Joshua','admin',1,'2026-09-13 12:22:15'),(2,'emmanuelokure@omg.com','$2y$10$uoZltW441P7xTmIUMySFrufCiU4Ut1tk7mQ0Xyukdba50j1RSw0ra','okure emmanuel','technician',1,'2026-09-13 14:28:01');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'omg_diagnostics'
--

--
-- Dumping routines for database 'omg_diagnostics'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-21 15:01:11
