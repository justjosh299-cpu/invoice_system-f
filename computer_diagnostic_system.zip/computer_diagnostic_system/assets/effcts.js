/* OMG Dashboard effects — floating cards, confetti, chart entrance */

/* ---------- A. Card float stagger ---------- */
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('.cards .card, .cards .stat-card').forEach(function (c, i) {
    var delay = (i * 0.15).toFixed(2) + 's';
    c.style.animationDelay = delay;
  });
});

/* ---------- B. Confetti burst (pure JS, no library) ---------- */
window.confettiBurst = function (options) {
  options = options || {};
  var count    = options.count    || 90;
  var duration = options.duration || 2200;
  var colors   = options.colors   || ['#0b2545','#4d9dff','#e89c2a','#1b8f4a','#a12626','#7a4a00'];

  var canvas = document.createElement('canvas');
  canvas.style.cssText = 'position:fixed;inset:0;width:100vw;height:100vh;pointer-events:none;z-index:9999';
  document.body.appendChild(canvas);

  var ctx = canvas.getContext('2d');
  var dpr = window.devicePixelRatio || 1;
  canvas.width  = window.innerWidth  * dpr;
  canvas.height = window.innerHeight * dpr;
  ctx.scale(dpr, dpr);

  var W = window.innerWidth, H = window.innerHeight;
  var particles = [];

  for (var i = 0; i < count; i++) {
    var angle = Math.random() * Math.PI * 2;
    var speed = 3 + Math.random() * 6;
    particles.push({
      x: W / 2,
      y: H / 2,
      vx: Math.cos(angle) * speed * (0.6 + Math.random()),
      vy: Math.sin(angle) * speed * (0.6 + Math.random()) - 2,
      size: 6 + Math.random() * 6,
      color: colors[Math.floor(Math.random() * colors.length)],
      rot: Math.random() * Math.PI * 2,
      vr: (Math.random() - 0.5) * 0.3,
      life: duration,
      born: performance.now()
    });
  }

  function draw(now) {
    ctx.clearRect(0, 0, W, H);
    var alive = 0;
    particles.forEach(function (p) {
      var age = now - p.born;
      var t = age / p.life;
      if (t >= 1) return;
      alive++;

      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.15;              // gravity
      p.vx *= 0.99;              // friction
      p.rot += p.vr;

      var alpha = 1 - t;

      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot);
      ctx.globalAlpha = alpha;
      ctx.fillStyle = p.color;
      ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
      ctx.restore();
    });

    if (alive > 0) requestAnimationFrame(draw);
    else canvas.remove();
  }
  requestAnimationFrame(draw);
};