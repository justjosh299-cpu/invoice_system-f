OMG DIAGNOSTIC SYSTEM — v12.2
=============================

NEW IN v12.2
------------
1. BULK ACTIONS
   - Reports page: select multiple → mark CLOSED, delete, or export CSV
   - Invoices page: select multiple → mark PAID, delete, or export CSV

2. SPARE PARTS INVENTORY
   - parts.php         — list, search, low-stock filter
   - parts_new.php     — add a new part
   - parts_edit.php    — edit existing
   - parts_move.php    — record stock in / out, see per-part history
   - parts_movements.php — full movement log (last 500)
   - Dashboard banner shows low-stock / out-of-stock alerts

3. RECURRING INVOICES
   - recurring.php       — list schedules, "Run due now" button
   - recurring_new.php   — create a schedule (weekly/monthly/quarterly/yearly)
   - recurring_edit.php  — edit / pause / resume
   - Auto-runs on Dashboard load for any schedule whose next_run <= today
   - Can also be triggered by cron: index.php?run_recurring=1

4. QUOTATIONS
   - quotations.php     — list, filter by status
   - quote_new.php      — create with line items
   - quote_edit.php     — edit
   - quote_view.php     — view, Accept, Convert to Invoice
   - quote_pdf.php      — PDF with logo + coat of arms

NEW NAV LINKS
-------------
Parts, Recurring, Quotations

HOW TO USE — PARTS ON A TICKET
------------------------------
1. Add parts you keep in stock via Parts → + Add Part
2. When a repair uses a part, open the part → Stock In/Out → enter
   negative quantity and reason "Used on repair", note the ticket no.
3. Dashboard shows a warning banner if any part is at/below reorder level

HOW TO USE — RECURRING
----------------------
1. Recurring → + New Schedule
2. Set client, amount, frequency, first run date
3. Every time the dashboard is opened (or cron runs),
   due schedules create invoices automatically

HOW TO USE — QUOTATIONS
-----------------------
1. Quotations → + New Quote
2. Add line items, save
3. On the quote view: click "Accept" when client agrees
4. Then click "Convert to Invoice" — creates a real invoice

INSTALL
-------
1. Save install.php, run it once, delete it
2. Hard-refresh browser (Ctrl+F5)