OMG DIAGNOSTIC SYSTEM — v14.1
=============================

NEW IN v14.1 (Part 1 of 2)
--------------------------
GROUP A — SAFETY
  1. Restore from Backup        restore.php
     - Lists all backups in C:\system_diag\backups
     - Preview before restoring
     - Auto-snapshots current DB before restore
     - Upload your own .sql file to restore

  2. Ticket Aging Report        aging.php
     - Buckets: 0-3, 4-7, 8-14, 15-30, 30+ days
     - Filter by device and technician
     - Excel export

GROUP B — MONEY
  3. Repair Cost Worksheet      cost_worksheet.php
     - Part picker from inventory (auto-deducts on save)
     - Labour hours × rate
     - Discount, VAT, currency
     - One click -> create DRAFT invoice

  4. Deposits / Advances        deposits.php
     - Record money received before invoicing
     - Auto-applied to the next invoice on the same ticket
     - Shows on ticket view + worksheet

  5. Client Statement           client_statement.php
     - Date range: all invoices + payments
     - Running balance column
     - Print / PDF / Excel export

  6. Excel Export               excel_export.php
     - Formatted .xls (opens in Excel, LibreOffice, Sheets)
     - Types: reports, invoices, aging, statement

NEW FILES
---------
restore.php
aging.php
deposits.php
cost_worksheet.php
client_statement.php
excel_export.php
config_v14.php

INSTALL
-------
1. Save this as install.php
2. Visit install.php once
3. Delete install.php
4. Add to config.php (near the top):
      require_once __DIR__ . '/config_v14.php';
5. Hard-refresh browser

Coming in Part 2 (Group C):
  - Bulk status change
  - Technician dashboard
  - WhatsApp share
  - Brand colour setting
  - Global search
  - Dark mode everywhere
  - Login audit log