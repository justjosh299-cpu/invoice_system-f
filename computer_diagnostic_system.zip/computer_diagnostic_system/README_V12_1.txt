OMG DIAGNOSTIC SYSTEM — v12.1
=============================

NEW IN v12.1
------------
1. CSV EXPORTS (top of Dashboard and Invoices pages, plus direct links)
   - export.php?type=reports    → all reports
   - export.php?type=invoices   → all invoices
   - export.php?type=activity   → activity log (admin only)
   - export.php?type=clients    → client list
   - export.php?type=payments   → payment history
   Files open cleanly in Excel (UTF-8 BOM).

2. DASHBOARD CHARTS (local SVG, no external libraries)
   - Revenue — last 6 months (bar chart)
   - Ticket status breakdown (donut)
   - Technician workload (top 5 bar chart)

3. INVOICE SEARCH — new filters
   - Paid? → All / Fully paid / Unpaid-Partial
   - Amount ≥ / ≤
   - Issued date range (already existed)

4. BATCH PRINT INVOICES
   - Tick checkboxes in the invoice list
   - Click "🖨 Batch print selected"
   - One PDF with all selected invoices, one per page

FILES CHANGED / ADDED
---------------------
+ assets/charts.js           (local SVG chart helper)
+ export.php                 (CSV exports)
+ invoice_batch_pdf.php      (multi-invoice PDF)
~ index.php                  (added charts + export buttons)
~ invoices.php               (new filters + batch select)

HOW TO USE
----------
- Open Dashboard → export buttons top-right
- Open Invoices → filter by Paid? / amount range → tick rows → Batch print
- Everything else works as before

INSTALL
-------
1. Save install.php, run it once, delete it
2. Hard-refresh browser (Ctrl+F5) so new CSS/JS load