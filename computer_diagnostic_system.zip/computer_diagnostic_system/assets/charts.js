/* Minimal SVG chart helpers — with entrance animations */
window.OMGChart = {
  bar: function(el, data, options) {
    options = options || {};
    var w = options.width || 400;
    var h = options.height || 140;
    var pad = options.pad || 20;
    var padB = options.padB || 34;
    var padL = options.padL || 44;
    var max = Math.max.apply(null, data.map(function(d){return d.value;}).concat([1]));
    var bw = (w - padL - pad) / data.length;

    var total = data.length;
    var step = 1;
    if (total > 10) step = Math.ceil(total / 10);
    if (total > 40) step = Math.ceil(total / 8);

    var svgNS = "http://www.w3.org/2000/svg";
    var svg = document.createElementNS(svgNS, "svg");
    svg.setAttribute("viewBox", "0 0 " + w + " " + h);
    svg.style.width = w + "px";
    svg.style.maxWidth = "100%";
    svg.style.height = "auto";

    function elFromString(s) {
      var div = document.createElementNS(svgNS, "g");
      div.innerHTML = s;
      return div;
    }

    // Axes
    svg.innerHTML =
      '<line x1="'+padL+'" y1="'+(h-padB)+'" x2="'+(w-pad)+'" y2="'+(h-padB)+'" stroke="#cfd8e3"/>' +
      '<line x1="'+padL+'" y1="'+pad+'" x2="'+padL+'" y2="'+(h-padB)+'" stroke="#cfd8e3"/>';

    // Grid + y labels
    for (var g = 0; g <= 4; g++) {
      var y = pad + (h - padB - pad) * g / 4;
      var v = Math.round(max * (4 - g) / 4);
      svg.innerHTML += '<line x1="'+padL+'" y1="'+y+'" x2="'+(w-pad)+'" y2="'+y+'" stroke="#eef3f9"/>' +
                       '<text x="'+(padL-5)+'" y="'+(y+3)+'" text-anchor="end" font-size="9" fill="#6b7887">'+v+'</text>';
    }

    // Bars (start at height 0, animate up)
    var bars = [];
    data.forEach(function(d, i) {
      var bh = (h - padB - pad) * (d.value / max);
      var x = padL + i * bw + bw * 0.18;
      var yFinal = h - padB - bh;
      var bwUse = bw * 0.64;

      var rect = document.createElementNS(svgNS, "rect");
      rect.setAttribute("x", x);
      rect.setAttribute("width", bwUse);
      rect.setAttribute("height", 0);
      rect.setAttribute("y", h - padB);
      rect.setAttribute("fill", options.color || "#0b2545");
      rect.setAttribute("rx", 2);
      rect.style.transition = "y .8s cubic-bezier(.2,.7,.3,1) " + (i * 0.03) + "s, height .8s cubic-bezier(.2,.7,.3,1) " + (i * 0.03) + "s";
      svg.appendChild(rect);
      bars.push({ rect: rect, y: yFinal, h: bh });

      var showLabel = (i % step === 0) || (i === total - 1);
      if (showLabel) {
        var lbl = document.createElementNS(svgNS, "text");
        lbl.setAttribute("x", x + bwUse / 2);
        lbl.setAttribute("y", h - padB + 12);
        lbl.setAttribute("text-anchor", "middle");
        lbl.setAttribute("font-size", "9");
        lbl.setAttribute("fill", "#52616f");
        lbl.textContent = d.label;
        svg.appendChild(lbl);
      }

      if (d.value > 0) {
        var valT = document.createElementNS(svgNS, "text");
        valT.setAttribute("x", x + bwUse / 2);
        valT.setAttribute("y", yFinal - 3);
        valT.setAttribute("text-anchor", "middle");
        valT.setAttribute("font-size", "9");
        valT.setAttribute("fill", "#0b2545");
        valT.setAttribute("font-weight", "600");
        valT.style.opacity = "0";
        valT.style.transition = "opacity .4s ease " + (0.6 + i * 0.03) + "s";
        valT.textContent = d.value;
        svg.appendChild(valT);
        setTimeout((function(t){ return function(){ t.style.opacity = "1"; }; })(valT), 50);
      }
    });

    el.innerHTML = "";
    el.appendChild(svg);

    // Trigger bar growth after a tick so transitions apply
    requestAnimationFrame(function () {
      bars.forEach(function (b) {
        b.rect.setAttribute("y", b.y);
        b.rect.setAttribute("height", b.h);
      });
    });
  },

  donut: function(el, data, options) {
    options = options || {};
    var w = options.size || 150;
    var h = w;
    var r = w * 0.34;
    var cx = w/2, cy = h/2;
    var thick = w * 0.15;
    var total = data.reduce(function(s,d){return s + d.value;}, 0) || 1;

    var svgNS = "http://www.w3.org/2000/svg";
    var svg = document.createElementNS(svgNS, "svg");
    svg.setAttribute("viewBox", "0 0 " + w + " " + h);
    svg.style.width = w + "px";
    svg.style.maxWidth = "100%";
    svg.style.height = "auto";

    var arcLen = 2 * Math.PI * r;

    var angle = -Math.PI/2;
    data.forEach(function(d, i) {
      var frac = d.value / total;
      var a2 = angle + frac * Math.PI * 2;
      var largeArc = frac > 0.5 ? 1 : 0;
      var x1 = cx + r * Math.cos(angle), y1 = cy + r * Math.sin(angle);
      var x2 = cx + r * Math.cos(a2), y2 = cy + r * Math.sin(a2);
      if (frac > 0) {
        var path = document.createElementNS(svgNS, "path");
        path.setAttribute("d", "M " + x1 + " " + y1 + " A " + r + " " + r + " 0 " + largeArc + " 1 " + x2 + " " + y2);
        path.setAttribute("stroke", d.color);
        path.setAttribute("stroke-width", thick);
        path.setAttribute("fill", "none");
        path.setAttribute("stroke-dasharray", arcLen);
        path.setAttribute("stroke-dashoffset", arcLen);
        path.style.transition = "stroke-dashoffset .9s ease " + (0.1 + i * 0.12) + "s";
        svg.appendChild(path);
        var pathLen = frac * arcLen;
        requestAnimationFrame(function (p, len) {
          return function () { p.setAttribute("stroke-dashoffset", arcLen - len); };
        }(path, pathLen));
      }
      angle = a2;
    });

    var t1 = document.createElementNS(svgNS, "text");
    t1.setAttribute("x", cx); t1.setAttribute("y", cy + 4);
    t1.setAttribute("text-anchor", "middle");
    t1.setAttribute("font-size", (w*0.13));
    t1.setAttribute("font-weight", "700");
    t1.setAttribute("fill", "#0b2545");
    t1.textContent = total;
    svg.appendChild(t1);

    var t2 = document.createElementNS(svgNS, "text");
    t2.setAttribute("x", cx); t2.setAttribute("y", cy + w*0.11);
    t2.setAttribute("text-anchor", "middle");
    t2.setAttribute("font-size", (w*0.055));
    t2.setAttribute("fill", "#6b7887");
    t2.textContent = "total";
    svg.appendChild(t2);

    el.innerHTML = "";
    el.appendChild(svg);
  }
};